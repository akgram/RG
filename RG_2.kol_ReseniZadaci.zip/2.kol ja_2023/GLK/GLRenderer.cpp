#include "StdAfx.h"
#include "GLRenderer.h"
#include "GL\gl.h"
#include "GL\glu.h"
#include "GL\glaux.h"
#include "GL\glut.h"
#include "DImage.h"
//#pragma comment(lib, "GL\\glut32.lib")

CGLRenderer::CGLRenderer(void)
{
	lamp = 0;
	side = 0;
	top = 0;
	bot = 0;
	right = 0;
	left = 0;
	back = 0;
	front = 0;

	alfaCam = 1;
	betaCam = 1;
	rCam = 70;

	arm1 = 0;
	arm2 = 0;
	head = 0;
}

CGLRenderer::~CGLRenderer(void)
{
}

bool CGLRenderer::CreateGLContext(CDC* pDC)
{
	PIXELFORMATDESCRIPTOR pfd ;
   	memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));
   	pfd.nSize  = sizeof(PIXELFORMATDESCRIPTOR);
   	pfd.nVersion   = 1; 
   	pfd.dwFlags    = PFD_DOUBLEBUFFER | PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW;   
   	pfd.iPixelType = PFD_TYPE_RGBA; 
   	pfd.cColorBits = 32;
   	pfd.cDepthBits = 24; 
   	pfd.iLayerType = PFD_MAIN_PLANE;
	
	int nPixelFormat = ChoosePixelFormat(pDC->m_hDC, &pfd);
	
	if (nPixelFormat == 0) return false; 

	BOOL bResult = SetPixelFormat (pDC->m_hDC, nPixelFormat, &pfd);
  	
	if (!bResult) return false; 

   	m_hrc = wglCreateContext(pDC->m_hDC); 

	if (!m_hrc) return false;

	return true;	
}

void CGLRenderer::PrepareScene(CDC *pDC)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	//---------------------------------
	glClearColor(1, 1, 1, 1);
	glEnable(GL_DEPTH_TEST);

	glEnable(GL_TEXTURE_2D);
	lamp = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\lamp.jpg");
	side = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\side.jpg");
	top = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\top.jpg");
	bot = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\bot.jpg");
	right = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\right.jpg");
	left = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\left.jpg");
	back = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\back.jpg");
	front = LoadTexture("C:\\Users\\krstic\\Desktop\\RG\\2.kol\\GLK\\front.jpg");


	//---------------------------------
	wglMakeCurrent(NULL, NULL);
}

void CGLRenderer::DrawScene(CDC *pDC)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	//---------------------------------

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	double eyeX = rCam * sin(betaCam) * cos(alfaCam);
	double eyeY = rCam * cos(betaCam);
	double eyeZ = rCam * sin(betaCam) * sin(alfaCam);

	gluLookAt( eyeX, eyeY, eyeZ,0, 0, 0,0, 1, 0 );
	DrawAxes();

	DrawEnvCube(100);
	DrawLamp();

	glFlush();
	SwapBuffers(pDC->m_hDC);

	//---------------------------------
	wglMakeCurrent(NULL, NULL);
}

void CGLRenderer::Reshape(CDC *pDC, int w, int h)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	//---------------------------------
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(50, (double)w / (double)h, 0.1, 2000);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//---------------------------------
	wglMakeCurrent(NULL, NULL);
}

void CGLRenderer::DestroyScene(CDC *pDC)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	// ... 
	glDeleteTextures(1, &lamp);
	glDeleteTextures(1, &side);
	glDeleteTextures(1, &bot);
	glDeleteTextures(1, &top);
	glDeleteTextures(1, &right);
	glDeleteTextures(1, &left);
	glDeleteTextures(1, &back);
	glDeleteTextures(1, &front);
	wglMakeCurrent(NULL,NULL); 
	if(m_hrc) 
	{
		wglDeleteContext(m_hrc);
		m_hrc = NULL;
	}
}

void CGLRenderer::DrawAxes()
{
	//gluLookAt(50, 50, 100, 0, 0, 0, 0, 1, 0);

	glBegin(GL_LINES);

	glColor3f(0, 0, 1);
	glVertex3f(0, 0, 0);
	glVertex3f(50, 0, 0);

	glColor3f(1, 0, 0);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 50, 0);

	glColor3f(0, 1, 0);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 0, 50);

	glEnd();
}


UINT CGLRenderer::LoadTexture(char* fileName)
{
	UINT texID;
	DImage img;
	img.Load(CString (fileName));
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glGenTextures(1, &texID);
	glBindTexture(GL_TEXTURE_2D, texID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, img.Width(), img.Height(), GL_BGRA_EXT, GL_UNSIGNED_BYTE, img.GetDIBBits());

	return texID;
}

void CGLRenderer::DrawEnvCube(double a)
{
	glColor3f(1, 1, 1);
	glEnable(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, bot);
	glBegin(GL_QUADS);
		glNormal3f(0, -1, 0);

		glTexCoord2f(0, 0);
		glVertex3f(-a / 2, 0, -a / 2);

		glTexCoord2f(1, 0);
		glVertex3f(a / 2, 0, -a / 2);

		glTexCoord2f(1, 1);
		glVertex3f(a / 2, 0, a / 2);

		glTexCoord2f(0, 1);
		glVertex3f(-a / 2, 0, a / 2);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, side);
	glBegin(GL_QUADS);
		glNormal3f(0, 0, 1);
		
		glTexCoord2f(0, 0);
		glVertex3f(-a / 2, a, -a / 2);

		glTexCoord2f(0, 1);
		glVertex3f(-a / 2, 0, -a / 2);

		glTexCoord2f(1, 1);
		glVertex3f(a / 2, 0, -a / 2);

		glTexCoord2f(1, 0);
		glVertex3f(a / 2, a, -a / 2);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, left);
	glBegin(GL_QUADS);
		glNormal3f(1, 0, 0);

		glTexCoord2f(0, 0);
		glVertex3f(-a / 2, a, a / 2);

		glTexCoord2f(0, 1);
		glVertex3f(-a / 2, 0, a / 2);

		glTexCoord2f(1, 1);
		glVertex3f(-a / 2, 0, -a / 2);

		glTexCoord2f(1, 0);
		glVertex3f(-a / 2, a, -a / 2);
	glEnd();

	/*glBindTexture(GL_TEXTURE_2D, right);
	glBegin(GL_QUADS);
		glNormal3f(-1, 0, 0);

		glTexCoord2f(0, 0);
		glVertex3f(a / 2, a, -a / 2);

		glTexCoord2f(0, 1);
		glVertex3f(a / 2, 0, -a / 2);

		glTexCoord2f(1, 1);
		glVertex3f(a / 2, 0, a / 2);

		glTexCoord2f(1, 0);
		glVertex3f(a / 2, a, a / 2);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, back);
	glBegin(GL_QUADS);
		glNormal3f(0, 0, -1);

		glTexCoord2f(0, 0);
		glVertex3f(a / 2, a, a / 2);

		glTexCoord2f(0, 1);
		glVertex3f(a / 2, 0, a / 2);

		glTexCoord2f(1, 1);
		glVertex3f(-a / 2, 0, a / 2);

		glTexCoord2f(1, 0);
		glVertex3f(-a / 2, a, a / 2);
	glEnd();*/

	glBindTexture(GL_TEXTURE_2D, top);
		glBegin(GL_QUADS);
		glNormal3f(0, -1, 0);

		glTexCoord2f(0, 0);
		glVertex3f(-a / 2, a, -a / 2);

		glTexCoord2f(0, 1);
		glVertex3f(-a / 2, a, a / 2);

		glTexCoord2f(1, 1);
		glVertex3f(a / 2, a, a / 2);

		glTexCoord2f(1, 0);
		glVertex3f(a / 2, a, -a / 2);
	glEnd();
}

void CGLRenderer::DrawCylinder(double r1, double r2, double h, int nSeg, int texMode, bool bIsOpen)
{
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, lamp);

	double alfa = 2 * 3.14 / nSeg;

	if (!bIsOpen)
	{
		glBegin(GL_TRIANGLE_FAN);
			//glNormal3f(0, 1, 0);
			glTexCoord2f(0.5, 0.25);
			glVertex3f(0, h, 0);

			for (int i = 0; i <= nSeg; i++)
			{
				double x = r1 * cos(i * alfa);
				double z = r1 * sin(i * alfa);

				glTexCoord2f(0.5 + (x / r1) / 4, 0.25 + (z / r1) / 4);
				glVertex3f(x, h, z);
			}
		glEnd();

		glBegin(GL_TRIANGLE_FAN);
			//glNormal3f(0, -1, 0);
			glTexCoord2f(0.5, 0.25);
			glVertex3f(0, 0, 0);

			for (int i = 0; i <= nSeg; i++)
			{
				double x = r2 * cos(i * alfa);
				double z = r2 * sin(i * alfa);

				glTexCoord2f(0.5 + (x / r1) / 4, (z / r1) / 4 + 0.25);
				glVertex3f(x, 0, z);
			}
		glEnd();


		glBegin(GL_QUADS);
			
			for (int i = 0; i < nSeg; i++)
			{
				double x1 = r1 * cos(i * alfa);
				double z1 = r1 * sin(i * alfa);

				double x2 = r2 * cos(i * alfa);
				double z2 = r2 * sin(i * alfa);

				double x12 = r1 * cos((i + 1) * alfa);
				double z12 = r1 * sin((i + 1) * alfa);

				double x22 = r2 * cos((i + 1) * alfa);
				double z22 = r2 * sin((i + 1) * alfa);

				glTexCoord2f((double)i / nSeg, 1.0);
				glVertex3f(x1, h, z1);

				glTexCoord2f((double)(i + 1) / nSeg, 1.0);
				glVertex3f(x12, h, z12);

				glTexCoord2f((double)(i + 1) / nSeg, 0.5);
				glVertex3f(x22, 0, z22);

				glTexCoord2f((double)i / nSeg, 0.5);
				glVertex3f(x2, 0, z2);
			}

		glEnd();
	}
	else
	{
		glBegin(GL_TRIANGLE_FAN);
		//glNormal3f(0, -1, 0);
		glTexCoord2f(0.5, 0.25);
		glVertex3f(0, 0, 0);

		for (int i = 0; i <= nSeg; i++)
		{
			double x = r2 * cos(i * alfa);
			double z = r2 * sin(i * alfa);

			glTexCoord2f(0.5 + (x / r1) / 4, (z / r1) / 4 + 0.25);
			glVertex3f(x, 0, z);
		}
		glEnd();

		glBegin(GL_QUADS);

		for (int i = 0; i < nSeg; i++)
		{
			double x1 = r1 * cos(i * alfa);
			double z1 = r1 * sin(i * alfa);

			double x2 = r2 * cos(i * alfa);
			double z2 = r2 * sin(i * alfa);

			double x12 = r1 * cos((i + 1) * alfa);
			double z12 = r1 * sin((i + 1) * alfa);

			double x22 = r2 * cos((i + 1) * alfa);
			double z22 = r2 * sin((i + 1) * alfa);

			glTexCoord2f((double)i / nSeg, 1.0);
			glVertex3f(x1, h, z1);

			glTexCoord2f((double)(i + 1) / nSeg, 1.0);
			glVertex3f(x12, h, z12);

			glTexCoord2f((double)(i + 1) / nSeg, 0.5);
			glVertex3f(x22, 0, z22);

			glTexCoord2f((double)i / nSeg, 0.5);
			glVertex3f(x2, 0, z2);
		}

		glEnd();
	}
}

void CGLRenderer::DrawLampBase()
{
	DrawCylinder(7, 8, 2, 16, 0, false);
}

void CGLRenderer::DrawLampArm()
{
	glPushMatrix();
	glTranslatef(0, 0, -1);
	glRotatef(90, 1, 0, 0);
	DrawCylinder(3, 3, 2, 16, 0, false);
	glPopMatrix();

	glPushMatrix();
	DrawCylinder(1, 1, 15, 16, 0, false);
	glPopMatrix();
}

void CGLRenderer::DrawLampHead()
{
	glPushMatrix();
	glTranslatef(0, 0, -1);
	glRotatef(90, 1, 0, 0);
	DrawCylinder(2, 2, 2, 16, 0, false);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-3, -4, 0);
	DrawCylinder(2, 2, 1, 16, 0, false);
	glTranslatef(0, 1, 0);

	DrawCylinder(3, 3, 5, 16, 0, false);
	glTranslatef(0, 5, 0);

	DrawCylinder(6, 3, 5, 16, 0, true);
	glPopMatrix();
}

void CGLRenderer::DrawLamp()
{
	DrawLampBase();
	glRotatef(30 + arm1, 0, 0, 1);
	DrawLampArm();
	glTranslatef(0, 15, 0);
	glRotatef(-60 + arm2, 0, 0, 1);
	DrawLampArm();
	glTranslatef(0, 15, 0);
	glRotatef(-90 + head, 0, 0, 1);
	DrawLampHead();
}
