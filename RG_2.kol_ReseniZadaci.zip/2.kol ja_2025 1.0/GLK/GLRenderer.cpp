#include "StdAfx.h"
#include "GLRenderer.h"
#include "GL\gl.h"
#include "GL\glu.h"
#include "GL\glaux.h"
#include "GL\glut.h"
#include "DImage.h"
//#pragma comment(lib, "GL\\glut32.lib")

CGLRenderer::CGLRenderer(void)
{
	slika = 0;
	alfa = 1;
	beta = 1;
	rCam = 100;
	ugao = 0;
	postolje = 0;
}

CGLRenderer::~CGLRenderer(void)
{
}

bool CGLRenderer::CreateGLContext(CDC* pDC)
{
	PIXELFORMATDESCRIPTOR pfd ;
   	memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));
   	pfd.nSize  = sizeof(PIXELFORMATDESCRIPTOR);
   	pfd.nVersion   = 1; 
   	pfd.dwFlags    = PFD_DOUBLEBUFFER | PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW;   
   	pfd.iPixelType = PFD_TYPE_RGBA; 
   	pfd.cColorBits = 32;
   	pfd.cDepthBits = 24; 
   	pfd.iLayerType = PFD_MAIN_PLANE;
	
	int nPixelFormat = ChoosePixelFormat(pDC->m_hDC, &pfd);
	
	if (nPixelFormat == 0) return false; 

	BOOL bResult = SetPixelFormat (pDC->m_hDC, nPixelFormat, &pfd);
  	
	if (!bResult) return false; 

   	m_hrc = wglCreateContext(pDC->m_hDC); 

	if (!m_hrc) return false; 

	return true;	
}

void CGLRenderer::PrepareScene(CDC *pDC)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	//---------------------------------
	glClearColor(1, 1, 1, 1);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	
	slika = LoadTexture("slika.jpg");
	
	//---------------------------------
	wglMakeCurrent(NULL, NULL);
}

void CGLRenderer::DrawScene(CDC *pDC)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	//---------------------------------

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	double xCam = rCam * sin(beta) * cos(alfa);
	double yCam = rCam * cos(beta);
	double zCam = rCam * sin(beta) * sin(alfa);

	gluLookAt(xCam, yCam, zCam, 0, 0, 0, 0, 1, 0);

	DrawAxes();
	//DrawRect(3, 7, 10);
	//DrawPrism(2, 5, 9, 10, true);
	//DrawLampHead(4, 7, 10);
	//DrawLampBody(4, 15, 10, ugao);
	
	//DrawPrism(10, 6, 10, 10, true);
	DrawPaintEastel(8, 30, 10, postolje, ugao, 0, 0);


	glFlush();
	SwapBuffers(pDC->m_hDC);
	//---------------------------------
	wglMakeCurrent(NULL, NULL);
}

void CGLRenderer::InitScene()
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);

	SetLightingParams();
	setLightParams(GL_LIGHT0);

	GLfloat diff[] = { 0.8f, 0.2f, 0.2f, 1.0f };
	SetMaterial(diff);
}


void CGLRenderer::SetLightingParams()
{
	GLfloat ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f };
	GLboolean localViewer = GL_TRUE;
	GLboolean twoSide = GL_TRUE;

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, localViewer);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, twoSide);

	glEnable(GL_LIGHTING);
}

void CGLRenderer::setLightParams(int glLight)
{
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	GLfloat light_position[] = { 0.0f, 0.0f, 0.0f, 1.0f }; // pozicija
	GLfloat light_direction[] = { 0.0f, 0.0f, -1.0f };      // ka -Z osi

	glLightfv(glLight, GL_AMBIENT, light_ambient);
	glLightfv(glLight, GL_DIFFUSE, light_diffuse);
	glLightfv(glLight, GL_SPECULAR, light_specular);
	glLightfv(glLight, GL_POSITION, light_position);
	glLightfv(glLight, GL_SPOT_DIRECTION, light_direction);

	glLightf(glLight, GL_SPOT_CUTOFF, 45.0f);      // ugao konusa
	glLightf(glLight, GL_SPOT_EXPONENT, 10.0f);    // koncentracija

	// mala atenuacija (slabljenje sa rastojanjem)
	glLightf(glLight, GL_CONSTANT_ATTENUATION, 1.0f);
	glLightf(glLight, GL_LINEAR_ATTENUATION, 0.05f);
	glLightf(glLight, GL_QUADRATIC_ATTENUATION, 0.0f);

	glEnable(glLight);
}

void CGLRenderer::SetMaterial(float diffuse[])
{
	GLfloat ambient[] = { diffuse[0] * 0.5f, diffuse[1] * 0.5f, diffuse[2] * 0.5f, 1.0f };
	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat emission[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat shininess = 64.0f;

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emission);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
}


void CGLRenderer::Reshape(CDC *pDC, int w, int h)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	//---------------------------------
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	gluPerspective(45, (double)w / (double)h, 1, 1000);
	glMatrixMode(GL_MODELVIEW);
	//---------------------------------
	wglMakeCurrent(NULL, NULL);
}

void CGLRenderer::DestroyScene(CDC *pDC)
{
	wglMakeCurrent(pDC->m_hDC, m_hrc);
	// ... 

	glDeleteTextures(1, &slika);

	wglMakeCurrent(NULL,NULL); 
	if(m_hrc) 
	{
		wglDeleteContext(m_hrc);
		m_hrc = NULL;
	}
}

void CGLRenderer::DrawAxes()
{
	glPushMatrix();
	glBegin(GL_LINES);
	glColor3f(0, 0, 1);
	glVertex3f(0, 0, 0);
	glVertex3f(50, 0, 0);

	glColor3f(1, 0, 0);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 50, 0);

	glColor3f(0, 1, 0);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 0, 50);
	glEnd();
	glPopMatrix();
}

void CGLRenderer::DrawRect(float a, float b, int n)
{
	glPushMatrix();
	//glRotated(90, 0, 0, 1);



	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			float x = -a / 2 + i * a / n;
			float y = -b / 2 + j * b / n;

			glBegin(GL_QUADS);
				glNormal3f(0, 0, 1);

				glTexCoord2f(i / n, j / n);
				glVertex3f(x, y, 0);

				glTexCoord2f((i + 1) / n, j / n);
				glVertex3f(x + a / n, y, 0);

				glTexCoord2f((i + 1) / n, (j + 1) / n);
				glVertex3f(x + a / n, y + b / n, 0);

				glTexCoord2f(i / n, (j + 1) / n);
				glVertex3f(x, y + b / n, 0);
			glEnd();
		}
	}

	glPopMatrix();
}

void CGLRenderer::DrawPrism(float a, float b, float c, int n, bool drawRight)
{
	glPushMatrix(); // prednja
		glTranslated(0, 0, c / 2);
		glNormal3f(0, 0, 1);
		DrawRect(a, b, n);
	glPopMatrix();

	glPushMatrix(); // zadnja
		glTranslated(0, 0, -c / 2);
		glNormal3f(0, 0, -1);
		DrawRect(a, b, n);
	glPopMatrix();

	if (drawRight)
	{
		glPushMatrix(); // desna
			glTranslated(a / 2, 0, 0);
			glRotated(90, 0, 1, 0);
			glNormal3f(1, 0, 0);
			DrawRect(c, b, n);
		glPopMatrix();
	}

	glPushMatrix(); // leva
		glTranslated(-a / 2, 0, 0);
		glRotated(90, 0, 1, 0);
		glNormal3f(-1, 0, 0);
		DrawRect(c, b, n);
	glPopMatrix();

	glPushMatrix(); // gornja
		glTranslated(0, b / 2, 0);
		glRotated(90, 1, 0, 0);
		glNormal3f(0, 1, 0);
		DrawRect(a, c, n);
	glPopMatrix();

	glPushMatrix(); // donja
		glTranslated(0, -b / 2, 0);
		glRotated(90, 1, 0, 0);
		glNormal3f(0, -1, 0);
		DrawRect(a, c, n);
	glPopMatrix();

}

void CGLRenderer::DrawLampHead(float w, float h, int n)
{
	glPushMatrix();
		//glTranslated(0, 0.5 * w / 2, 0);
		DrawPrism(h, 0.5 * w, 0.5 * w, n, true);

		glTranslated(h / 2, 0, 0);
		DrawPrism(0.5 * h, w, w, n, false);

	glPopMatrix();
}

void CGLRenderer::DrawLampBody(float w, float h, int n, float alfa)
{
	glPushMatrix();
		glTranslated(0, h / 2, 0);
		DrawPrism(0.2 * w, h, 0.2 * w, n, true);
		glTranslated(0.3 * h / 2, h / 2, 0);
		glRotated(90 + alfa, 0, 0, 1);
		DrawPrism(0.2 * w, 0.3 * h, 0.2 * w, n, true);


		glTranslated(0, -0.3 * h / 2, 0);
		glRotated(-180, 0, 0, 1);
		DrawLampHead(4, 7, n);
	glPopMatrix();


}

void CGLRenderer::DrawPaintEastel(float w, float h, int n, float slide, float alfa, float beta, float gama)
{
	glColor3f(1, 1, 0);
	glPushMatrix(); // osnova 1
		glRotated(90, 0, 0, 1);
		DrawPrism(0.2 * w, 0.2 * h, 0.2 * w, n, true);
	glPopMatrix();

	glPushMatrix(); // osnova 2
		glRotated(90, 1, 0, 0);
		DrawPrism(0.2 * w, 0.2 * h, 0.2 * w, n, true);
	glPopMatrix();

	glPushMatrix(); // uspravna
		glTranslated(0, h / 2 + 0.2 * w, 0);
		DrawPrism(0.2 * w, h, 0.2 * w, n, true);
	glPopMatrix();

	glPushMatrix();
		glTranslated(0, 0.9 * h + (slide * h), 0); // 1 - 0.1  = 0.9
		glRotated(90, 1, 0, 0);
		DrawPrism(0.2 * w, 0.4 * h, 0.2 * w, n, true); // poprecna 1
		glTranslated(0, 0, 0.3 * h);
		DrawPrism(0.2 * w, 0.4 * h, 0.2 * w, n, true); // poprecna 2

		glColor3f(1, 0, 0);
		glTranslated(0, 0, -0.3 * h / 2);
		glRotated(90, 0, 0, 1);
		glRotated(90, 1, 0, 0);
		DrawPrism(0.6 * h, 0.3 * h, 0.2 * w, n, true); // postolje


		glTranslated(0, -0.15 * h, 0);
		glRotated(90, 0, 1, 0);
		glRotated(90, 0, 0, 1);
		DrawLampBody(w, h, n, ugao);
	glPopMatrix();

	glPushMatrix();
		
	glPopMatrix();
}

UINT CGLRenderer::LoadTexture(char* fileName)
{
	UINT texId;
	DImage img;
	img.Load(CString(fileName));
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	glGenTextures(1, &texId);
	glBindTexture(GL_TEXTURE_2D, texId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, img.Width(), img.Height(), GL_BGRA_EXT, GL_UNSIGNED_BYTE, img.GetDIBBits());

	return texId;
}
